import { Reporter, FullConfig, Suite, TestCase, TestResult } from "@playwright/test/reporter";
import { ExecOptions } from "./types/execOptions.types";
declare class OdhinPlaywrightReporter implements Reporter {
    private generate;
    constructor(execOptions: ExecOptions);
    onBegin(config: FullConfig, suite: Suite): Promise<void>;
    onTestEnd(testCase: TestCase, result: TestResult): Promise<void>;
    onEnd(): Promise<void>;
    onStdOut(chunk: string): Promise<void>;
    onStdErr(chunk: string): Promise<void>;
}
export default OdhinPlaywrightReporter;
