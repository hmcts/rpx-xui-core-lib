export interface ExecTestCase {
    id: string;
    title: string;
    filename: string;
    projectId: string;
    projectInfo: boolean;
    retries: number;
    tags: string[];
    annotations: Annotation[];
    titlePath: string[];
}
export interface Annotation {
    type: string;
    description: string;
}
