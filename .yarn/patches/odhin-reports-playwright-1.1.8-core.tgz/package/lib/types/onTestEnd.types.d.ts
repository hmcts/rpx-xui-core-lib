export interface OnTestEnd {
    method: string;
    params: Params;
}
export interface Params {
    test: Test;
    result: Result;
}
export interface Result {
    id: string;
    duration: number;
    status: string;
    errors: Error[];
    attachments: Attachment[];
}
export interface Attachment {
    name: string;
    path: string;
    contentType: string;
}
export interface Error {
    message: string;
    stack: string;
    location: Location;
    snippet: string;
}
export interface Location {
    file: string;
    column: number;
    line: number;
}
export interface Test {
    testId: string;
    expectedStatus: string;
    annotations: any[];
    timeout: number;
}
