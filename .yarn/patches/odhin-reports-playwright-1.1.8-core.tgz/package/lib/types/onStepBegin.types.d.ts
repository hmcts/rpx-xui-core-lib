export interface OnStepBegin {
    method: string;
    params: Params;
}
export interface Params {
    testId: string;
    resultId: string;
    step: Step;
}
export interface Step {
    id: string;
    title: string;
    category: string;
    startTime: number;
    location: Location;
    parentStepId: string;
}
export interface Location {
    file: string;
    line: number;
    column: number;
}
