export interface ExecTestResult {
    id?: string;
    duration: number;
    status: string;
    retry: number;
    startTime: Date;
    parallelIndex: number;
    errors: Array<TestError>;
    stderr: Array<string | Buffer>;
    stdout: Array<string | Buffer>;
    steps: Array<TestStep>;
    attachments: Array<TestAttachment>;
    workerIndex: number;
}
export interface TestError {
    location?: Location;
    message?: string;
    snippet?: string;
    stack?: string;
    value?: string;
}
export interface TestStep {
    id?: string;
    category: string;
    duration: number;
    error?: TestError;
    location?: Location;
    parent?: TestStep;
    startTime: Date;
    steps: Array<TestStep>;
    title: string;
}
export interface TestAttachment {
    name: string;
    contentType: string;
    path?: string;
    body?: Buffer;
}
export interface Location {
    column: number;
    file: string;
    line: number;
}
