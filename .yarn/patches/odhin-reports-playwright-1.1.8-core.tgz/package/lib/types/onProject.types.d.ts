export interface OnProject {
    method: string;
    params: Params;
}
export interface Params {
    project: Project;
}
export interface Project {
    id: string;
    name: string;
    outputDir: string;
    repeatEach: number;
    retries: number;
    testDir: string;
    testIgnore: any[];
    testMatch: TestMatch[];
    timeout: number;
    suites: Suite[];
    grep: Grep[];
    grepInvert: any[];
    dependencies: any[];
    snapshotDir: string;
}
export interface Grep {
    r: R;
}
export interface R {
    source: string;
    flags: string;
}
export interface Suite {
    type: string;
    title: string;
    fileId: string;
    parallelMode: string;
    location: Location;
    suites: Suite[];
    tests: Test[];
}
export interface Location {
    file: string;
    line: number;
    column: number;
}
export interface Test {
    testId: string;
    title: string;
    location: Location;
    retries: number;
}
export interface TestMatch {
    s: string;
}
