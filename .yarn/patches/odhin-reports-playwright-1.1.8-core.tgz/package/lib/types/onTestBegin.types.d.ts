export interface OnTestBegin {
    method: string;
    params: Params;
}
export interface Params {
    testId: string;
    result: Result;
}
export interface Result {
    id: string;
    retry: number;
    workerIndex: number;
    parallelIndex: number;
    startTime: number;
}
