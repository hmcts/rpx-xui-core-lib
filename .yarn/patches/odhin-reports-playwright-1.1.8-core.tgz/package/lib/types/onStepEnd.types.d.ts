export interface OnStepEnd {
    method: string;
    params: Params;
}
export interface Params {
    testId: string;
    resultId: string;
    step: Step;
}
export interface Step {
    id: string;
    duration: number;
    error: Error;
}
export interface Error {
    message: string;
    stack: string;
    location: Location;
    snippet: string;
}
export interface Location {
    file: string;
    column: number;
    line: number;
}
