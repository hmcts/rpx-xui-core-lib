import { ExecTestCase } from "./execTestCase.types";
import { ExecTestResult } from "./execTestResult.types";
export interface TestReport {
    testCase: ExecTestCase;
    result: ExecTestResult;
}
