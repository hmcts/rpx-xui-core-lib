export interface OnStdIO {
    method: string;
    params: Params;
}
export interface Params {
    testId: string;
    resultId: string;
    type: string;
    data: string;
    isBase64: boolean;
}
