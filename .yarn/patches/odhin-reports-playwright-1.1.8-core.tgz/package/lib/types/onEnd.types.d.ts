export interface OnEnd {
    method: string;
    params: Params;
}
export interface Params {
    result: Result;
}
export interface Result {
    status: string;
    startTime: number;
    duration: number;
}
