import { ExecProjectInfo } from "./execProjectInfo.types";
import { ExecFileInfo } from "./execFileInfo.types";
export interface ExecInfo {
    projectName: string;
    totalPassed: number;
    totalFailed: number;
    totalTimedOut: number;
    totalSkipped: number;
    totalInterrupted: number;
    totalFlaky: number;
    totalTests: number;
    startTime: string;
    endTime: string;
    execFiles: ExecFileInfo[];
    execProjects: ExecProjectInfo[];
}
