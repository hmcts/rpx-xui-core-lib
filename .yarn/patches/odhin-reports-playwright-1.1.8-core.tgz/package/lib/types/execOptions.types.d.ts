export interface ExecOptions {
    testFolder: string;
    title: string;
    testEnvironment: string;
    project: string;
    release: string;
    embedAssets: boolean;
    embedAttachments: boolean;
    outputFolder: string;
    startServer: boolean;
    consoleLog: boolean;
    simpleConsoleLog: boolean;
    consoleError: boolean;
    testOutput: boolean | "only-on-failure";
    consoleTestOutput: boolean;
    initialTheme: string;
    indexFilename: string;
    testGroupOnConsole: boolean;
    testProjectOnConsole: boolean;
    testListColumns: string[];
}
